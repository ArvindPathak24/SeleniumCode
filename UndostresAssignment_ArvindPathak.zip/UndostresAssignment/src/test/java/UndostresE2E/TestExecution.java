package UndostresE2E;
import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pageObjectModel.HomePage;
import pageObjectModel.PaymnetPage;
import pageObjectModel.PopupPage;
import resources.Base;

public class TestExecution extends Base {
	
	@BeforeTest
	public void initialize() throws IOException
	{
		driver = initializeDriver();
		
		driver.manage().window().maximize();
	}
	
	
	@Test
	public void Home() throws IOException, InterruptedException								
	{
		HomePage hp = new HomePage(driver);			//Object of HomePage Clas
		hp.ElementName();							// calling ElementName Function
		hp.SendingValues();
	}
	
	
	
	@Test
	public void Payment() throws InterruptedException, IOException
	{
		PaymnetPage pp = new PaymnetPage(driver);
		Thread.sleep(3000);
		pp.OnPaymentPage();
		pp.CardPayment();
		pp.Entering_Details();
		
	}
	
	
	@Test
	public void PopUP() throws IOException, InterruptedException
	{
		PopupPage pp = new PopupPage(driver);
		Thread.sleep(4000);
		pp.Email();
	}
	
	
	@AfterTest
	public void close() throws InterruptedException
	{	Thread.sleep(10000);
		driver.close();
	}
	

}
