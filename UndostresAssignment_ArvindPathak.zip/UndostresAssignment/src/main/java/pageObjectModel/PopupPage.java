package pageObjectModel;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PopupPage {
	
	
	WebDriver driver;
	
	String EmailID = "automationUDT1@gmail.com";
	String pass = "automationUDT123";

	public PopupPage(WebDriver driver)							//Constructor of HomePage Class
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);					//PageFactory Concept
	}
	
	@FindBy(xpath = "//input[@id='usrname']")
	WebElement email;
	
	@FindBy(xpath = "//input[@id='psw']")
	WebElement password;
	
	
	@FindBy(xpath = "//form[@role='form']/div[4][1]/div/div")
	WebElement captcha;
	
	
	@FindBy(xpath = "//button[@name='loginbtn']")
	WebElement submitbtn;
	
	
	public void Email() throws IOException, InterruptedException
	{
		email.sendKeys(EmailID);
		password.sendKeys(pass);
		captcha.click();
		submitbtn.click();
		
	}

}
