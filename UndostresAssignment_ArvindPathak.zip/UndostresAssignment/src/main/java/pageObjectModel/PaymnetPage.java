package pageObjectModel;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class PaymnetPage {
	WebDriver driver;
	
	public PaymnetPage(WebDriver driver)							//Constructor of HomePage Class
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);					//PageFactory Concept
	}
	
	
	@FindBy(xpath = "//p[text()='Tarjeta']")
	WebElement card;
	
	@FindBy(xpath = "//tr[@id='radio-n']")
	WebElement new_card;
	
	@FindBy(xpath = "//input[@id='cardnumberunique']")
	WebElement card_number;
	
	@FindBy(xpath = "//input[@placeholder='mm']")
	WebElement month1;
	
	@FindBy(xpath = "//input[@placeholder='yy']")
	WebElement year;
	
	@FindBy(xpath = "//input[@placeholder='CVV']")
	WebElement cvv;
	
	@FindBy(xpath = "//input[@placeholder='Correo electrónico']")
	WebElement email;
	
	@FindBy(xpath = "//button[@id='paylimit']")
	WebElement pay;

	public void OnPaymentPage()
	{
		String URL = driver.getCurrentUrl();
		String Actual_URL = "https://prueba.undostres.com.mx/payment.php";
		Assert.assertEquals(URL, Actual_URL);
		System.out.print("We are on Payment Page");
	}
	
	
	public void CardPayment() throws InterruptedException
	{
		card.click();
		Thread.sleep(2000);
		new_card.click();
		Thread.sleep(3000);
		card_number.click();
		
				
	}
	
	public void Entering_Details() throws IOException, InterruptedException
	{
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\resources\\undostres.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(1);
		Row row = sheet.getRow(4);
		String Email = row.getCell(1).getStringCellValue();
		
		Thread.sleep(2000);
		
		card_number.sendKeys("4111111111111111");
		month1.sendKeys("11");
		year.sendKeys("25");
		cvv.sendKeys("111");
		email.sendKeys(Email);
		Thread.sleep(1000);
		
		pay.click();
		
		
	}
	
	
	
}	

