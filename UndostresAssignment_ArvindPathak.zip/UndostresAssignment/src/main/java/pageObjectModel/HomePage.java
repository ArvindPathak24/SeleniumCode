package pageObjectModel;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class HomePage {
	
	WebDriver driver;
	
	public HomePage(WebDriver driver)							//Constructor of HomePage Class
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);					//PageFactory Concept
	}
	
	List<String> list = new ArrayList<>();						
	
	
	
	@FindBy(xpath = "//div[@class='col-sm-12 menulist selector ']/a")
	List <WebElement> elements;
	
	@FindBy(xpath = "//input[@suggestmobile='mobile-numbers']")
	WebElement number;
	
	@FindBy(xpath = "//input[@data-qa='celular-operator']")
	WebElement operator;
	
	@FindBy(xpath = "//input[@data-qa='celular-amount']")
	WebElement recharge;
	
	@FindBy(xpath = "//div[contains(@class,'ul-container')]/ul/li")
	List <WebElement> dropdown;
	
	@FindBy(xpath = "//li[@data-show='$10 (Recarga Saldo)']/a/div")
	WebElement recharge_amount;
	
	@FindBy(xpath = "//button[@data-qa='celular-pay']")
	WebElement following_btn;
	
	
	
	
//Function1	
	@SuppressWarnings("unused")
	public void ElementName()
	{
		for(int i=0; i<elements.size(); i++)
		{
			//list.add(elements.get(i).getText());						//To get the name of all elements present in Homepage
			if(elements.get(i).getText().contains("Recargac"))
			{
				elements.get(i).click();	
			}
				break;
		}		
	 }
	
	
//Function2
	
	
	public void SendingValues() throws IOException, InterruptedException
	{
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\resources\\undostres.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Row row = sheet.getRow(0);
		String cellval = row.getCell(1).getStringCellValue();				// Getting MobileNumber from Excel
		
		Row row1 = sheet.getRow(1);
		String operatorName = row1.getCell(1).getStringCellValue();			// Getting Operator Name from Excel
		
		operator.click();													//Clicking on Operator Field
		for(int j=0; j<dropdown.size(); j++)								// Getting the Operator name i.e. Telecel using for loop
		{
			if(dropdown.get(j).getText().contains(operatorName))			// if Telcel found, click on Telcel and then break
			{
				dropdown.get(j).click();
				break;
			}
		}
		Thread.sleep(2000);
		number.sendKeys(cellval);											// Sending MobileNumber 
		Thread.sleep(2000);
		recharge.click(); 													// Click on Recharge
		Thread.sleep(2000);
		recharge_amount.click();											// Selecting $10 Recharge Amount
		Thread.sleep(2000);
		following_btn.click();
		
		workbook.close();
		
	}
	
	
	
	

}
